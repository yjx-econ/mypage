- 1. International Credit Cycles (with Feng Dong and Zhiwei Xu, reject and resubmit at Journal of International Economics), 2022 [Paper]


- 2. Policy Spillovers and Housing Cycles in China, 2022


- 3. Financing Innovation (with Chang Liu, Yuchao Peng, and Zhiwei Xu), 2024


- 4. Fish and Bear’s Paw: Dilemmas in Integrating Environment into R&D Policy (with Hongyu Nian, Huanhuan Wang, and Zhiwei Xu), 2024.


- 5. Debt Management and Strategic Interactions in Top-down Bureaucracy: Evidence from China (with Xi Qu, and  Zhiwei Xu, under review), 2023 [Paper]


- 6. The Pricing of Local Government Bonds in China: A Bank-government Relationship Perspective (with Xi Qu and Zhiwei Xu, under review), 2021 [Paper]


- 7. Spatial Dynamic Panel Data Models with High Order Time Varying Endogenous Weights Matrices (with Jiajun Zhang and Xi Qu, revise and resubmit to Econometric Reviews), 2021


- 8. 董丰、许志伟、俞锦祥，僵尸企业、信贷错配与宏观系统风险，2018，《经济研究》修改再审


- 9. 许志伟、张哲玮、俞锦祥，目标与均衡：央地策略互动的理论视角，2023

